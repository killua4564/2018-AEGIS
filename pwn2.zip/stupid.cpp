#include <bits/stdc++.h>
#include <unistd.h>
#include <fcntl.h>
#include <malloc.h>

#define uint unsigned int
#define ul unsigned long

using namespace std;

static const string king_pic = "\n\
　　　　　　　   　　   .,^､\n\
　　　　　　　   .r-‐i'''''i''''‐-､\n\
　　　　　　　  o|  ｏ!　 ｏ  ｏ  !o\n\
　　　　　　　 .|＼__|｀‐´｀‐／|__/|\n\
　　　　　　 __ |_, ─''''''''''''─ /__\n\
　　　　 , '　　   （・） （・）　　 ｀ ‐,\n\
　　　　/ //　     ヽ-､＿__ ,-r' 　　 　 ヽ\n\
　　　 |　! !　　  ﾉ｀'ｰ--‐‐'´ヽ　  　　  .|\n\
　　　 |　! j　　　 　 　　　　　　　     .|\n\
　 　　|　　　　　   King Slime　    　    |\n\
　　　　'i　　　　　　　　　　　　   　_ ノ'\n\
　　　　　｀''─ ＿　　　　        ＿ ─''´\n\
　　　　　　　　　￣￣ ￣￣ ￣￣\n\
";

static const string minion_pic = "\n\
             ╭--------------╮\n\
             | I'm Slime :3 |\n\
             ╰--------------╯\n\
           __/\n\
        ﾉ\\\n\
      ／  \\\n\
    ／     ＼\n\
  ／   ⊙  ⊙  ＼\n\
 |             |\n\
 |    ╰----╯   |\n\
  ＼_________／\n\
  \n\
";

static const string versoin = "1.0";

enum LANG
{
    None = -1,
    ASM,
    C,
    Ruby,
    Java,
    Python,
    Javascript,
};

static const string LANG_NAME[] =
{
    "ASM",
    "C",
    "Ruby",
    "Java",
    "Python",
    "Javascript",
};

static const string c_ver[] = {"C89", "C9X", "C11"};

map<string, uint> skills;

uint secure_rand()
{
    int fd = open("/dev/urandom", O_RDONLY);
    if(fd < 0)
    {
        puts("Failed to open /dev/urandom");
        exit(-1);
    }
    else
    {
        char data[5] = {};
        ssize_t result = read(fd, data, 4);
        if (result < 0)
        {
            puts("Failed to read from /dev/urandom");
            exit(-1);
        }
        else
        {
            uint num = 0;
            num = ((data[3] << 24) | (data[2] << 16) | (data[1] << 8) | (data[0]));
            close(fd);
            return num;
        }
    }
}

int battle (int you, int enemy)
{
    /* Rule:                             */
    /* 0 < 1, 1 < 2, 2 < 3, 3 < 4, 4 < 0 */
    /* 0 < 1, 0 > 4, 0 = 0, 0 = 2, 0 = 3 */

    int temp = you % 5;
    while(temp < 0) temp += 5;
    
    you = temp;
    cout << "You: " << you << endl;
    cout << "Enemy: " << enemy << endl;

    if (((you+1)%5) == enemy) return -1; // you lose
    else if (((you+4)%5) == enemy) return 1; // you win
    else return 0; // draw
}

string get_color(LANG lg)
{
    switch(lg)
    {
        case ASM:
            return "\033[0m";
        case C:
            return "\033[96m";
        case Ruby:
            return "\033[91m";
        case Java:
            return "\033[93m";
    }
}

class Slime
{
    public:
        Slime(string name_, LANG lang_):name(name_), lang(lang_), exp(0), lg_name(LANG_NAME[lang_]){}
        virtual void fight() {}
        void info()
        {
            cout << "Here comes the " << name << " !" << endl;
            cout << "If you defeat him, you can gain " << exp << " " << lg_name << " exp !" << endl;
        }
        virtual ~Slime()
        {
            name.clear();
            lang = None;
            exp = 0;
            lg_name.clear();
        }
    protected:
        string name;
        LANG lang;
        uint exp;
        string lg_name;
};

class SlimeMinion : public Slime 
{
    public:
        SlimeMinion(string name_, LANG lang_) : Slime(name_, lang_), number(new uint[5])
        {
            exp = secure_rand() % 100 + 50;
            seed += 4444;
        }
        void fight()
        {
            string color = get_color(lang);
            cout << color << minion_pic << "\033[0m"<<endl;
            info();
            genNum();
            int win = 0, lose = 0;
            for (int i = 0; i < 5; i++) 
            {
                int you = 0;
                cout << "Please enter number "<< i+1 << " :";
                cin >> you;
                int res = battle(you, number[i]);
                switch(res) 
                {
                    case -1: // lose
                        lose++;
                        break;
                    case 0: // draw = win
                        win++;
                        break;
                    case 1:
                        win++;
                        break;
                }
                cout << "You: " << win << " pt / " << name << " : " << lose << " pt." << endl;
            }
            if ( win > lose ) // you win !
            {
                cout << endl << "You defeat the "<< name << " !!" << endl;
                cout << "You gain " << exp << " "<< lg_name << " exp !" << endl;
                skills[lg_name] += exp;
            }
            else // you lose
            {
                cout << endl << "You lose :(" << endl;
                cout << "The " << name << " traps you in his body >\"< " << endl;
                cout << "But don't worry, you'll be free after 1 second :)" << endl;
                sleep(1);
            }
        }
        ~SlimeMinion()
        {
            delete [] number;
            number = nullptr;
        }

    private:
        uint *number;
        static int seed;
        void genNum()
        {
            srand(seed);
            for (int i = 0 ; i < 5 ; i++)
            {
                number[i] = rand() % 5;
            }
        }
};

int SlimeMinion::seed = 0x44444444;

class SlimeKing : public Slime 
{
    public:
        SlimeKing(string name_, LANG lang_) : Slime(name_, lang_), number(0)
        {
            exp = secure_rand() % 100 + 250;
        }
        void fight()
        {
            string color = get_color(lang);
            cout << color << king_pic << "\033[0m"<<endl;
            info();
            int lose = 0, win = 0;
            for (int i = 0; i < 5; i++) 
            {
                srand(time(NULL));
                number = rand() % 5;
                int you = 0;
                cout << "Please enter number "<< i+1 << " :";
                cin >> you;
                int res = battle(you, number);
                switch(res) 
                {
                    case -1: // lose
                        lose++;
                        break;
                    case 0: // draw = lose
                        lose++;
                        break;
                    case 1:
                        win++;
                        break;
                }
                cout << "You: " << win << " pt / " << name << " : " << lose << " pt." << endl;
            }
            if ( win > lose ) // you win !
            {
                cout << endl << "You defeat the " << name << " !!" << endl;
                cout << "You gain " << exp << " "<< lg_name << " exp !" << endl;
                skills[lg_name] += exp;
            }
            else // you lose
            {
                cout << endl << "You lose :(" << endl;
                cout << "The "<< name <<" traps you in his body G__G" << endl;
                cout << "But don't worry, you'll be free after 10 seconds :)" << endl;
                sleep(10);
            }
        }
        ~SlimeKing() { number = 0; }
    private:
        uint number;
};

class Language
{
    public:
        Language():lang(None), ratio(0){}
        Language(LANG lang_, ul ratio_):lang(lang_), name(LANG_NAME[lang_]), ratio(ratio_){}
        void basic_info()
        {
            cout << endl << "Language: " << name << endl;
            cout << "Ratio: " << ratio << " %" << endl;
        }
        LANG get_lang(){ return lang; }
        void set_ratio(ul r) { ratio = r; }
        virtual void info(){}
        virtual ~Language()
        {
            lang = None;
            name.clear();
            ratio = 0;
        }
    protected:
        LANG lang;
        string name;
        ul ratio;
};

class L_ASM : public Language
{
    public:
        L_ASM(ul r):Language(ASM, r){}
        void info()
        {
            basic_info();
            cout << "Arch: " << arch << endl;
        }
        void set_arch()
        {
            cout << "Please input the architecture of the ASM: ";
            cin >> arch;
        }
        ~L_ASM() { arch.clear(); }
    private:
        string arch;
};

class L_Ruby : public Language
{
    public:
        L_Ruby(ul r):Language(Ruby, r), version(0.0){}
        void info()
        {
            basic_info();
            cout << "Ruby version: " << version << endl;
        }
        void set_version()
        {
            cout << "Please input the version number: ";
            scanf("%lf", &version);
        }
        ~L_Ruby() { version = 0.0; }
    private:
        double version;
};

class L_Python : public Language
{
    public:
        L_Python(ul r):Language(Python, r), version(0.0){}
        void info()
        {
            basic_info();
            cout << "Python version: " << version << endl;
        }
        void set_version()
        {
            cout << "Please input the version number: ";
            scanf("%lf", &version);
        }
        ~L_Python() { version = 0.0; }
    private:
        double version;
};

class L_C : public Language
{
    public:
        L_C(ul r):Language(C, r),version(nullptr){}
        L_C(const L_C &copy)
        {
            version = new char[strlen(copy.version)+1];
            strcpy(version, copy.version);
        }
        L_C& operator=(const L_C &copy)
        {
            version = new char[strlen(copy.version)+1];
            strcpy(version, copy.version);
        }
        void info()
        {
            basic_info();
            cout << "C standard version: " << version << endl;
        }
        void set_version()
        {
            uint choice = 0;
            while(1)
            {
                cout << "Please select a C standard version:" << endl;
                for (int i = 0; i < 3; i++) 
                {
                    cout << i+1 << ". " << c_ver[i] << endl;
                }
                cout << "Your choice: ";
                cin >> choice;
                if (choice >= 1 && choice <= 3)
                {
                    version = new char[5];
                    strcpy(version, c_ver[choice-1].c_str());
                    return;
                }
                else
                {
                    cout << "Invalid choice." << endl;
                }
            }
        }
        ~L_C() 
        {
            memset(version, 0, malloc_usable_size(version));
            delete [] version;
            version = nullptr;
        }
    private:
        char *version;
};

class L_Java : public Language
{
    public:
        L_Java(ul r):Language(Java, r),version(0.0){}
        void info()
        {
            basic_info();
            cout << "Java version: " << version << endl;
        }
        void set_version()
        {
            cout << "Please input the version number: ";
            scanf("%lf", &version);
        }
        ~L_Java() { version = 0.0; }
    private:
        double version;
};

class L_Javascript : public Language
{
    public:
        L_Javascript(ul r):Language(Javascript, r),version(nullptr){}
        L_Javascript(const L_Javascript &copy)
        {
            version = new char[strlen(copy.version)+1];
            strcpy(version, copy.version);
        }
        L_Javascript& operator=(const L_Javascript &copy)
        {
            version = new char[strlen(copy.version)+1];
            strcpy(version, copy.version);
        }
        void info()
        {
            basic_info();
            cout << "Supported javascript engine: " << versoin << endl;
        }
        void set_version()
        {
            if (version == nullptr) version = new char[30];
            cout << "Please enter the name of the supported javascript engine: ";
            read(0, version, 20);
        }
        ~L_Javascript() 
        {
            memset(version, 0, malloc_usable_size(version));
            delete [] version;
            version = nullptr;
        }
    private:
        char *version;
};

void set_lang(Language **l, LANG lang, ul r, bool just_edit)
{
    switch(lang)
    {
        case ASM:
        {
            L_ASM *temp = just_edit == true ? reinterpret_cast<L_ASM*>(*l) : new L_ASM(r);
            temp->set_arch();
            *l = temp;
            break;
        }
        case C:
        {
            L_C *temp = just_edit == true ? reinterpret_cast<L_C*>(*l) : new L_C(r);
            temp->set_version();
            *l = temp;
            break;
        }
        case Python:
        {
            L_Python *temp = just_edit == true ? reinterpret_cast<L_Python*>(*l) : new L_Python(r);
            temp->set_version();
            *l = temp;
            break;
        }
        case Java:
        {
            L_Java *temp = just_edit == true ? reinterpret_cast<L_Java*>(*l) : new L_Java(r);
            temp->set_version();
            *l = temp;
            break;
        }
        case Ruby:
        {
            L_Ruby *temp = just_edit == true ? reinterpret_cast<L_Ruby*>(*l) : new L_Ruby(r);
            temp->set_version();
            *l = temp;
            break;
        }
        case Javascript:
        {
            L_Javascript *temp = just_edit == true ? reinterpret_cast<L_Javascript*>(*l) : new L_Javascript(r);
            temp->set_version();
            *l = temp;
            break;
        }
    }
}

class Project
{
    public:
        Project()
        {
            lang_list[0] = nullptr;
            lang_list[1] = nullptr;
        }
        virtual bool compatible(LANG lang1, LANG lang2){}
        virtual LANG select_lang(){}
        void show_info()
        {
            cout << endl << "Project language details :" << endl;
            for (int i = 0; i < 2; i++) 
            {
                lang_list[i]->info();
            }
        }
        void change_language()
        {
            for (int i = 0; i < 2; i++) 
            {
                ul r;
                cout << endl << "Select language " << i+1 << ": "<<endl;
                LANG new_lang = select_lang();
                cout << "Ratio: ";
                scanf("%lu", &r);

                if ( compatible( new_lang, lang_list[i]->get_lang() ) ) // just edit
                {
                    lang_list[i]->set_ratio(r);
                    set_lang(&(lang_list[i]), new_lang, r, true); // just_edit = true;
                }
                else // replace with a new language
                {
                    delete lang_list[i];
                    set_lang(&(lang_list[i]), new_lang, r, false); // just_edit = false;
                }
            }
        }
        void create()
        {
            for (int i = 0; i < 2; i++) 
            {
                ul r;
                cout << endl << "Select language " << i+1 << ": "<<endl;
                LANG lang = select_lang();

                cout << "Ratio: ";
                scanf("%lu", &r);
                set_lang(&(lang_list[i]), lang, r, false); // just edit = false;
            }
        }
        void manage()
        {
            uint choice = 0;
            while(1)
            {
                cout << endl << "1. Show project language details" << endl;
                cout << "2. Change languages" << endl;
                cout << "3. Back to main menu" << endl;
                cout << "Your choice: ";
                cin >> choice;
                switch(choice)
                {
                    case 1:
                        show_info();
                        break;
                    case 2:
                        change_language();
                        break;
                    case 3:
                        return;
                    default:
                        cout << "Invalid choice." << endl;
                        break;
                }
            }
        }
        virtual ~Project()
        {
            delete lang_list[0];
            delete lang_list[1];
            lang_list[0] = nullptr;
            lang_list[1] = nullptr;
        }
    protected:
        Language *lang_list[2];
};

class Web : public Project
{
    public:
        Web(){}
        LANG select_lang()
        {
            bool jsok = skills["Javascript"] >= 500 ? true : false;
            uint choice = 0;
            while(1)
            {
                cout << "1. Ruby" << endl;
                cout << "2. Java" << endl;
                if (jsok) cout << "3. Javascript" << endl;
                cout << "Your choice: ";
                cin >> choice;
                
                if(choice == 1 || choice == 2 || (choice == 3 && jsok))
                {
                    switch(choice)
                    {
                        case 1:
                            return Ruby;
                        case 2:
                            return Java;
                        case 3:
                            return Javascript;
                    }
                }
                else
                {
                    cout << "Invalid choice." << endl;
                }
            }
        }
        bool compatible(LANG lang1, LANG lang2)
        {
            string s1 = LANG_NAME[lang1];  
            string s2 = LANG_NAME[lang2];

            /* 因為幹話王甲的關係只好這樣寫 */
            if(strstr(s2.c_str(), s1.c_str())) return true;
            else return false;
        }
        ~Web(){}
};

class Trojan : public Project
{
    public:
        Trojan(){}
        LANG select_lang()
        {
            bool pok = skills["Python"] >= 500 ? true : false;
            uint choice = 0;
            while(1)
            {
                cout << "1. ASM" << endl;
                cout << "2. C  " << endl;
                if (pok) cout << "3. Python" << endl;
                cout << "Your choice: ";
                cin >> choice;
                
                if(choice == 1 || choice == 2 || (choice == 3 && pok))
                {
                    switch(choice)
                    {
                        case 1:
                            return ASM;
                        case 2:
                            return C;
                        case 3:
                            return Python;
                    }
                }
                else
                {
                    cout << "Invalid choice." << endl;
                }
            }
        }
        bool compatible(LANG lang1, LANG lang2)
        {
            string big = LANG_NAME[lang1];  
            string small = LANG_NAME[lang2];
            if ( big.length() < small.length() ){ big.swap(small) ; }

            if (big == small) return true;
            else
            {
                /* 幹話王乙表示 C 跟 Python 長得好像喔 */
                if (big == "Python" && small == "C") return true;
                else return false;
            }
        }
        ~Trojan(){}
};

Web *pweb = nullptr;
Trojan *ptrojan = nullptr;

void make_web()
{
    pweb = new Web();
    pweb->create();
    skills["Javascript"] = 500;
}

void make_trojan()
{
    ptrojan = new Trojan();
    ptrojan->create();
    skills["Python"] = 500;
}

void boss()
{
    if( skills["C"] >= 500 && skills["ASM"] >= 500)
    {
        if(ptrojan == nullptr)
        {
            cout << endl << "Here comes the stupid bosses. They want you to make a trojan horse." << endl;
            cout << "幹話王甲 : 想當初我也有用組語寫過木馬呢" << endl;
            cout << "幹話王乙 : 是說你不覺得 C 跟 Python 長得很像嗎 ?" << endl;
            make_trojan();
            return;
        }
    }
    if( skills["Ruby"] >= 500 && skills["Java"] >= 500)
    {
        if(pweb == nullptr)
        {
            cout << endl << "Here comes the stupid bosses. They want you to make a website." << endl;
            cout << "幹話王甲 : 你會寫 Java 嘛，那你一定也會 Javascript 囉" << endl;
            cout << "幹話王乙 : 全院只有你會，你不做誰做 ?" << endl;
            make_web();
        }
    }
}

void manage_project()
{
    bool wok = pweb == nullptr ? false : true;
    bool tok = ptrojan == nullptr ? false : true;
    char c;
    if( !wok && !tok )
    {
        cout << "You need to make a project first." << endl;
        cout << "Fight slimes to improve your skills until your stupid bosses assign a project to you." << endl;
        return;
    }
    while(1)
    {
        cout << endl;
        if( wok ) cout << "Manage  [W]ebsite" << endl;
        if( tok ) cout << "Manage  [T]rojan" << endl;
        cout << "Back to [M]ain menu" << endl;
        cout << endl << "Your choice <";
        if( wok ) cout << "w/";
        if( tok ) cout << "t/";
        cout << "m> : ";
        cin >> c;

        if(tolower(c) == 'w' && wok)
        {
            pweb->manage();
            break;
        }
        else if (tolower(c) == 't' && tok)
        {
            ptrojan->manage();
            break;
        }
        else if (tolower(c) == 'm')
        {
            return;
        }
        else
        {
            cout << "Invalid choice." << endl;
        }
    }
}

void fight_slime()
{
    uint slime_id = secure_rand() % 5;
    Slime *enemy;
    if (slime_id  == 4) // slime king
    {
        uint king_id = (slime_id  + secure_rand() ) % 4;
        LANG lg = static_cast<LANG>(king_id);
        string lg_name = LANG_NAME[lg];
        string slime_name = "King of the "+ lg_name + " Slime";
        enemy = new SlimeKing(slime_name, lg);
    }
    else
    {
        LANG lg = static_cast<LANG>(slime_id);
        string lg_name = LANG_NAME[lg];
        string slime_name = lg_name + " Slime";
        enemy = new SlimeMinion(slime_name, lg);
    }
    enemy->fight();
    delete enemy;
    enemy = nullptr;

    boss();
}

void show_status()
{
    cout << "Your programming skills:\n" << endl;
    for (auto const & sk : skills)
    {
        cout.width(10); cout << left << sk.first << " : ";
        cout.width(5); cout << right << sk.second << " exp." << endl;
    }
}

void menu()
{
    cout << endl;
    cout << "**********************************************************" << endl;
    cout << "* The Programmer, the Slime and the Stupid Boss ( v"<< versoin << " ) *" << endl;    
    cout << "**********************************************************" << endl;
    cout << "* 1. Check status                                        *" << endl;
    cout << "* 2. Fight Slimes                                        *" << endl;
    cout << "* 3. Manage Projects                                     *" << endl;
    cout << "* 4. Exit                                                *" << endl;
    cout << "**********************************************************" << endl;
}

void init()
{
    setvbuf(stdin,0, 2, 0);
    setvbuf(stdout,0, 2, 0);
    setvbuf(stderr,0, 2, 0);

    for (int i = 0; i < 6; i++) 
    {
        string name = LANG_NAME[i];
        skills[name] = 0;
    }
}

int main(int argc, char *argv[])
{
    init();
    uint choice = 0;
    while(1)
    {
        menu();
        cout << "Your choice: ";
        cin >> choice;
        cout << endl;
        switch(choice) 
        {
            case 1:
                show_status();
                break;
            case 2:
                fight_slime();
                break;
            case 3:
                manage_project();
                break;
            case 4:
                exit(0);
                break;
            default:
                cout << "Invalid choice." << endl;
                break;
        }
    }
    return 0;
}    
