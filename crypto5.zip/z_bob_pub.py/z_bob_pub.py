import socket
L=int
h=pow
q=str
j=True
i=socket.socket
k=socket.AF_INET
V=socket.SOCK_STREAM
import threading
z=threading.Thread
import random
J=random.getrandbits
import hashlib
f=hashlib.pbkdf2_hmac
import binascii
import Crypto.Cipher.AES
p="Bob"
P=0xEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D
l="0xEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D"
G=2
B="2"
def Y(O,E):
 try:
  v=O.recv(1024).rstrip("\n").split("||")
  ga=L(v[1])
  b=J(80)
  gb=h(G,b,P)
  t="Hi, I'm Bob||{0}".format(gb)
  O.send(t)
  k=h(ga,b,P)
  Q=f('md5',q(k),b'5566',100000)
  b=O.recv(1024).rstrip("\n")
  A=Crypto.Cipher.AES.new(Q)
  a=A.decrypt(b)
  if a==AUTH:
   n=A.encrypt(FLAG)
   O.send(n)
  else:
   O.send("Wrong answer! Try again!")
 finally:
  O.close()
def x():
 try:
  s=i(k,V)
  s.bind(("210.65.10.132",35566))
  s.listen(10)
  while j:
   O,E=s.accept()
   T=z(target=Y,args=(O,E))
   T.start()
 finally:
  s.close()
if __name__=="__main__":
 x()

